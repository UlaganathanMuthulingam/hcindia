package com.maveric.onlineBanking.stepDef;

import com.maveric.onlineBanking.common.onlineBankingMethods;
import com.maveric.onlineBanking.runner.runner;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class onlineBankingStepdef {
	onlineBankingMethods online=new onlineBankingMethods();
	@Given("^online banking admin user logged in with valid credentials$")
	public void loginAsAdminuser()
	{
		online.adminlogin();
	}
	
	@When("^admin clicked User clicked User Details link$")
	public void clickUserDetailslnk()
	{
		online.clickingUserDetailslink();
	}
	
	@And("^email address link of first record clicked$")
	public void emailAddresslinkClicked()
	{
		online.clickingEmaillink();
	}
	@And("^click Modify email ID button after entering email in New Email ID field$") 
	public void enterNewEmailAddress()
	{
		online.updateEmailAddress();
		
	}
	  
	@Then("^verify updated email address in User Details List$")
	public void verifychangedEmailAddress()
	{
		online.verifyupdatedEmailAddress();
	}

	@When("^admin clicked Account details link$")
	public void clickingAccDetailslink()
	{
		
	}
	@And("^Account No link clicked from the list$")
	public void clickingAccountNo()
	{
		
	}
	@Then("^verify admin landed on customer User Details page$")
	public void verifyUserDetailsPage()
	{

}
}