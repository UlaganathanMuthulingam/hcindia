package com.maveric.onlineBanking.common;

import org.openqa.selenium.WebElement;

import com.maveric.onlineBanking.runner.runner;

public class onlineBankingMethods extends SeMethods  {

	public WebElement adminUserNametxt;
	public WebElement adminPasswordtxt;
	public WebElement adminLoginbtn;
	public WebElement pageTitlelbl;
	public WebElement adminUserDetailslnk;
	public WebElement adminUserEmaillnk;
	public WebElement adminChangeEmaillbl;
	public WebElement adminoldEmailAddresstxt;
	public WebElement adminnewEmailAddresstxt;
    public WebElement adminModifyEmailbtn;
    public WebElement adminAccountDetailslnk;
    SeMethods se=runner.semethod;
public void adminlogin() 
{
	se.startBrowser("chrome");
	se.driver.get("http://demo.rapidtestpro.com/admin/");
	adminUserNametxt=se.locateElement("id", objProp.getProperty("ADMIN_USERNAMETXT_ID"));
	adminPasswordtxt=se.locateElement("id", objProp.getProperty("ADMIN_PASSWORDTXT_ID"));
	adminLoginbtn=se.locateElement("id", objProp.getProperty("ADMIN_LOGINBTN_ID"));
	se.type(adminUserNametxt, testDataProp.getProperty("adminUsername"));
	se.type(adminPasswordtxt,testDataProp.getProperty("adminPassword"));
	se.click(adminLoginbtn);
	pageTitlelbl=se.locateElement("id", objProp.getProperty("ADMIN_HOMEPAGETITLE_ID"));
	se.verifyExactText(pageTitlelbl, testDataProp.getProperty("AdminPageTitle"));

}

public void clickingUserDetailslink()

{
	adminUserDetailslnk=se.locateElement("link", objProp.getProperty("ADMIN_USERDETAILS_LNK"));
	se.click(adminUserDetailslnk);
	pageTitlelbl=se.locateElement("id", objProp.getProperty("ADMIN_HOMEPAGETITLE_ID"));
	se.verifyExactText(pageTitlelbl, testDataProp.getProperty("userDetailspageTitle"));
}


public void clickingEmaillink()
{
	adminUserEmaillnk=se.locateElement("xpath",objProp.getProperty("ADMIN_FIRSTRECORD_EMAILADDRESS_XPATH"));
	String oldemailaddress=se.getText(adminUserEmaillnk);
	testDataProp.setProperty("OldEmailAddress", oldemailaddress);
	se.click(adminUserEmaillnk);
	adminChangeEmaillbl=se.locateElement("xpath", objProp.getProperty("ADMIN_CHANGE_EMAILPAGETITLE_XPATH"));
	se.verifyExactText(adminChangeEmaillbl, testDataProp.getProperty("changeEmailAddressTitle"));
	
}

public void updateEmailAddress()
{
	adminoldEmailAddresstxt=se.locateElement("id", objProp.getProperty("ADMIN_USERDETAILSTXT_OLD_EMAIL_ID"));
	se.verifyExactText(adminoldEmailAddresstxt, testDataProp.getProperty("OldEmailAddress"));
	adminnewEmailAddresstxt=se.locateElement("id",objProp.getProperty("ADMIN_USERDETAILSTXT_NEW_EMAIL_ID"));
	se.type(adminnewEmailAddresstxt, testDataProp.getProperty("newEmailAddress"));
	adminModifyEmailbtn=se.locateElement("id", objProp.getProperty("ADMIN_USERDETAILSBTN_MODIFYEMAIL_ID"));
	se.click(adminModifyEmailbtn);
	
}

public void verifyupdatedEmailAddress()
{
	adminUserEmaillnk=se.locateElement("xpath",objProp.getProperty("ADMIN_FIRSTRECORD_EMAILADDRESS_XPATH"));
	verifyExactText(adminUserEmaillnk, testDataProp.getProperty("newEmailAddress"));
}

public void clickingAccountDetailslink()
{
	//adminAccountDetailslnk=locateElement("link", locValue)
}

}
