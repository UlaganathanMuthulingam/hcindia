package com.maveric.onlineBanking.stepDef;

import org.openqa.selenium.WebElement;

import com.maveric.onlineBanking.common.SeMethods;
import com.maveric.onlineBanking.runner.runner;

import cucumber.api.java.en.Given;

public class dummycheck extends SeMethods {
	public WebElement adminUserNametxt;
	public WebElement adminPasswordtxt;
	public WebElement adminLoginbtn;
	public WebElement adminHomepageTitlelbl;
	public WebElement adminUserDetailslnk;
	public WebElement adminUserEmaillnk;
	public WebElement adminoldEmailAddresstxt;
	public WebElement adminnewEmailAddresstxt;
    public WebElement adminModifyEmailbtn;
	
	@Given("open URL")
	public void check() throws InterruptedException
	{
		SeMethods se=runner.semethod;
		se.startBrowser("chrome");
		se.driver.get("http://demo.rapidtestpro.com/admin/");
		adminUserNametxt=se.locateElement("id", objProp.getProperty("ADMIN_USERNAMETXT_ID"));
		adminPasswordtxt=se.locateElement("id", objProp.getProperty("ADMIN_PASSWORDTXT_ID"));
		adminLoginbtn=se.locateElement("id", objProp.getProperty("ADMIN_LOGINBTN_ID"));
		se.type(adminUserNametxt, testDataProp.getProperty("adminUsername"));
		se.type(adminPasswordtxt,testDataProp.getProperty("adminPassword"));
		se.click(adminLoginbtn);
		adminHomepageTitlelbl=se.locateElement("id", objProp.getProperty("ADMIN_HOMEPAGETITLE_ID"));
		se.verifyExactText(adminHomepageTitlelbl, "Admin Main Page");
		adminUserDetailslnk=se.locateElement("link", objProp.getProperty("ADMIN_USERDETAILS_LNK"));
		se.click(adminUserDetailslnk);
		adminUserEmaillnk=se.locateElement("xpath",objProp.getProperty("ADMIN_FIRSTRECORD_EMAILADDRESS_XPATH"));
		String oldemailaddress=se.getText(adminUserEmaillnk);
		testDataProp.setProperty("OldEmailAddress", oldemailaddress);
		se.click(adminUserEmaillnk);
		adminoldEmailAddresstxt=se.locateElement("id", objProp.getProperty("ADMIN_USERDETAILSTXT_OLD_EMAIL_ID"));
		se.verifyExactText(adminoldEmailAddresstxt, oldemailaddress);
		adminnewEmailAddresstxt=se.locateElement("id",objProp.getProperty("ADMIN_USERDETAILSTXT_NEW_EMAIL_ID"));
		se.type(adminnewEmailAddresstxt, testDataProp.getProperty("newEmailAddress"));
		adminModifyEmailbtn=locateElement("id", objProp.getProperty("ADMIN_USERDETAILSBTN_MODIFYEMAIL_ID"));
		se.click(adminModifyEmailbtn);
		se.verifyExactText(adminoldEmailAddresstxt, testDataProp.getProperty("newEmailAddress"));
		
	}

}
