package com.maveric.onlineBanking.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.maveric.onlineBanking.reports.Reporter;

public class SeMethods extends Reporter implements WdMethods {

	public RemoteWebDriver driver;
	public String citiUrl, merchantUrl;
	public int waitTime = 20;
	public static Properties configProp;
	public static Properties objProp;
	public static Properties testDataProp;
	public Actions action;


	public SeMethods() {
		configProp = new Properties();
		objProp = new Properties();
		testDataProp = new Properties();
		try {
			configProp.load(new FileInputStream(new File("./src/main/resources/config.properties")));
			objProp.load(new FileInputStream(new File("./src/main/resources/object.properties")));
			testDataProp.load(new FileInputStream(new File("./src/main/resources/testData.properties")));
			citiUrl = configProp.getProperty("CITI_URL");
			merchantUrl = configProp.getProperty("MERCHANT_URL");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void startBrowser(String browser) {
		try {

			if (browser.equalsIgnoreCase("chrome")) {
				System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
				driver = new ChromeDriver();
			} else {
				;
				System.setProperty("webdriver.ie.driver", "./drivers/iedriver.exe");
				driver = new InternetExplorerDriver();
			}

			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			// driver.get(url);
			// reportStep("The browser: "+browser+" launched successfully", "PASS");
		} catch (WebDriverException e) {
			// reportStep("The browser: "+browser+" could not be launched", "FAIL");
			e.printStackTrace();
		}
	}

	public WebElement locateElement(String locator, String locValue) {
		try {
			switch (locator) {
			case ("id"):
				return FluentWaitCall(driver.findElementById(locValue));
			case ("link"):
				return FluentWaitCall(driver.findElementByLinkText(locValue));
			case ("xpath"):
				return FluentWaitCall(driver.findElementByXPath(locValue));
			case ("name"):
				return FluentWaitCall(driver.findElementByName(locValue));
			case ("class"):
				return FluentWaitCall(driver.findElementByClassName(locValue));
			case ("tag"):
				return FluentWaitCall(driver.findElementByTagName(locValue));
			}
		} catch (NoSuchElementException e) {
			reportStep("The element with locator " + locValue + " not found.", "FAIL");
			throw e;
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while finding " + locator + " with the value " + locValue, "FAIL");
			throw e;
		}
		return null;
	}

	public List<WebElement> locateElements(String locator, String locValue) {
		try {
			switch (locator) {
			case ("id"):
				return driver.findElementsById(locValue);
			case ("link"):
				return driver.findElementsByLinkText(locValue);
			case ("xpath"):
				return driver.findElementsByXPath(locValue);
			case ("name"):
				return driver.findElementsByName(locValue);
			case ("class"):
				return driver.findElementsByClassName(locValue);
			case ("tag"):
				return driver.findElementsByTagName(locValue);
			}
		} catch (NoSuchElementException e) {
			reportStep("The List of element with locator " + locValue + " not found.", "FAIL");
			throw e;
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while finding " + locator + " with the value " + locValue, "FAIL");
			throw e;
		}
		return null;
	}

	public void type(WebElement ele, String data) {
		try {
			waitForVisibility(ele, waitTime);
			ele.clear();
			ele.sendKeys(data);
			reportStep("The data: " + data + " entered successfully in the field ", "PASS");
		} catch (InvalidElementStateException e) {
			reportStep("The data: " + data + " could not be entered in the field ", "FAIL");
			throw e;
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while entering " + data + " in the field ", "FAIL");
			throw e;
		}
	}

	public void click(WebElement ele) {
		String text = "";
		try {
			WebDriverWait wait = new WebDriverWait(driver, 40);
			wait.until(ExpectedConditions.elementToBeClickable(ele));
			text = ele.getText();
			ele.click();
			reportStep("The element " + text + " is clicked", "PASS");
		} catch (InvalidElementStateException e) {
			reportStep("The element: " + text + " could not be clicked", "FAIL");
			throw e;
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while clicking in the field :", "FAIL");
			throw e;
		}
	}

	public void clickWithNoSnap(WebElement ele) {
		String text = "";
		try {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(ele));
			text = ele.getText();
			ele.click();
			reportStep("The element :" + text + "  is clicked.", "PASS", false);

		} catch (InvalidElementStateException e) {
			reportStep("The element: " + text + " could not be clicked", "FAIL", false);
			throw e;
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while clicking in the field :", "FAIL", false);
			throw e;
		}
	}

	public String getText(WebElement ele) {
		String bReturn = "";
		try {
			waitForVisibility(ele, waitTime);
			bReturn = ele.getText();
		} catch (WebDriverException e) {
			reportStep("The element: " + ele + " could not be found.", "FAIL");
			throw e;
		}
		return bReturn;
	}

	public String getTitle() {
		String bReturn = "";
		try {
			bReturn = driver.getTitle();
		} catch (WebDriverException e) {
			reportStep("Unknown Exception Occured While fetching Title", "FAIL");
			throw e;
		}
		return bReturn;
	}

	public String getAttribute(WebElement ele, String attribute) {
		String bReturn = "";
		try {
			waitForVisibility(ele, waitTime);
			bReturn = ele.getAttribute(attribute);
		} catch (WebDriverException e) {
			reportStep("The element: " + ele + " could not be found.", "FAIL");
			throw e;
		}
		return bReturn;
	}

	public void selectDropDownUsingText(WebElement ele, String value) {
		try {
			waitForVisibility(ele, waitTime);
			new Select(ele).selectByVisibleText(value);
			reportStep("The dropdown is selected with text " + value, "PASS");

		} catch (WebDriverException e) {
			reportStep("The element: " + ele + " could not be found.", "FAIL");
			throw e;
		}

	}

	public void selectDropDownUsingValue(WebElement ele, String value) {
		try {
			waitForVisibility(ele, waitTime);
			new Select(ele).selectByValue(value);
			reportStep("The dropdown is selected with Value " + value, "PASS");
		} catch (WebDriverException e) {
			reportStep("The element: " + ele + " could not be found.", "FAIL");
			throw e;
		}

	}

	public void selectDropDownUsingIndex(WebElement ele, int index) {
		try {
			waitForVisibility(ele, waitTime);
			new Select(ele).selectByIndex(index);
			reportStep("The dropdown is selected with index " + index, "PASS");

		} catch (WebDriverException e) {
			reportStep("The element: " + ele + " could not be found.", "FAIL");
			throw e;
		}

	}

	public boolean verifyTitle(String title) {
		boolean bReturn = false;
		try {
			if (getTitle().equals(title)) {
				reportStep("The title of the page matches with the value :" + title, "PASS");
				bReturn = true;
			} else {
				reportStep("The title of the page:" + driver.getTitle() + " did not match with the value :" + title,
						"FAIL");
			}
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while verifying the title", "FAIL");
			throw e;
		}
		return bReturn;
	}

	public void verifyExactText(WebElement ele, String expectedText) {
		try {
			waitForVisibility(ele, waitTime);
			if (getText(ele).equals(expectedText)) {
				reportStep("The text: " + getText(ele) + " matches with the value :" + expectedText, "PASS");
			} else {
				reportStep("The text " + getText(ele) + " doesn't matches the actual " + expectedText, "FAIL");
			}
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while verifying the Text", "FAIL");
			throw e;
		}

	}

	public void verifyPartialText(WebElement ele, String expectedText) {
		try {
			waitForVisibility(ele, waitTime);
			if (getText(ele).contains(expectedText)) {
				reportStep("The expected text contains the actual " + expectedText, "PASS");
			} else {
				reportStep("The expected text doesn't contain the actual " + expectedText, "FAIL");
			}
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while verifying the Text", "FAIL");
			throw e;
		}
	}

	public void verifyExactAttribute(WebElement ele, String attribute, String value) {
		try {
			waitForVisibility(ele, waitTime);
			if (getAttribute(ele, attribute).equals(value)) {
				reportStep("The expected attribute :" + attribute + " value matches the actual " + value, "PASS");
			} else {
				reportStep("The expected attribute :" + attribute + " value does not matches the actual " + value,
						"FAIL");
			}
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while verifying the Attribute Text", "FAIL");
			throw e;
		}

	}

	public void verifyPartialAttribute(WebElement ele, String attribute, String value) {
		try {
			waitForVisibility(ele, waitTime);
			if (getAttribute(ele, attribute).contains(value)) {
				reportStep("The expected attribute :" + attribute + " value contains the actual " + value, "PASS");
			} else {
				reportStep("The expected attribute :" + attribute + " value does not contains the actual " + value,
						"FAIL");
			}
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while verifying the Attribute Text", "FAIL");
			throw e;
		}
	}

	public boolean verifySelected(WebElement ele) {
		try {
			waitForVisibility(ele, waitTime);
			if (ele.isSelected()) {
				reportStep("The element " + ele + " is selected", "PASS");
				return true;
			} else {
				reportStep("The element " + ele + " is not selected", "FAIL");
				return false;
			}
		} catch (WebDriverException e) {
			reportStep("WebDriverException : " + e.getMessage(), "FAIL");
			throw e;
		}
	}

	public boolean verifyDisplayed(WebElement ele) {
		try {
			waitForVisibility(ele, waitTime);
			if (ele.isDisplayed()) {
				reportStep("The element " + ele + " is visible", "PASS");
				return true;
			} else {
				reportStep("The element " + ele + " is not visible", "FAIL");
				return false;
			}
		} catch (WebDriverException e) {
			reportStep("WebDriverException : " + e.getMessage(), "FAIL");
			throw e;
		}
	}

	public boolean verifyEnabled(WebElement ele) {
		try {
			waitForVisibility(ele, waitTime);
			if (ele.isEnabled()) {
				reportStep("The element " + ele + " is visible", "PASS");
				return true;
			} else {
				reportStep("The element " + ele + " is not visible", "FAIL");
				return false;
			}
		} catch (WebDriverException e) {
			reportStep("WebDriverException : " + e.getMessage(), "FAIL");
			throw e;
		}
	}

	public void switchToWindow(int index) {
		try {
			Set<String> allWindowHandles = driver.getWindowHandles();
			List<String> allHandles = new ArrayList<>();
			allHandles.addAll(allWindowHandles);
			driver.switchTo().window(allHandles.get(index));
		} catch (NoSuchWindowException e) {
			reportStep("The driver could not move to the given window by index " + index, "PASS");
			throw e;
		} catch (WebDriverException e) {
			reportStep("WebDriverException : " + e.getMessage(), "FAIL");
			throw e;
		}
	}

	public void switchToFrame(WebElement ele) {
		try {
			waitForVisibility(ele, waitTime);
			driver.switchTo().frame(ele);
			reportStep("switch In to the Frame " + ele, "PASS");
		} catch (NoSuchFrameException e) {
			reportStep("WebDriverException : " + e.getMessage(), "FAIL");
			throw e;
		} catch (WebDriverException e) {
			reportStep("WebDriverException : " + e.getMessage(), "FAIL");
			throw e;
		}
	}

	public void switchToDefaultFrame() {
		try {
			driver.switchTo().defaultContent();
			reportStep("switch to default frame ", "PASS");
		} catch (NoSuchFrameException e) {
			reportStep("WebDriverException : " + e.getMessage(), "FAIL");
			throw e;
		} catch (WebDriverException e) {
			reportStep("WebDriverException : " + e.getMessage(), "FAIL");
			throw e;
		}
	}
	
	public boolean verifyDisabled(WebElement ele) {
		try {
			waitForVisibility(ele,waitTime);
			if(ele.isEnabled()) {
				System.out.println("Confirm is enabled");
				reportStep("The element "+ele+" is enabled","FAIL");
				return false;
			} else {
				reportStep("The element "+ele+" is disabled","PASS");
				return true;
			}
		} catch (WebDriverException e) {
			reportStep("WebDriverException : "+e.getMessage(), "FAIL");
			throw e;
		} 
	}


	public void acceptAlert() {
		String text = "";
		try {
			Alert alert = driver.switchTo().alert();
			text = alert.getText();
			alert.accept();
			reportStep("The alert " + text + " is accepted.", "PASS");
		} catch (NoAlertPresentException e) {
			reportStep("There is no alert present.", "FAIL");
			throw e;
		} catch (WebDriverException e) {
			reportStep("WebDriverException : " + e.getMessage(), "FAIL");
			throw e;
		}
	}

	public void dismissAlert() {
		String text = "";
		try {
			Alert alert = driver.switchTo().alert();
			text = alert.getText();
			alert.dismiss();
			reportStep("The alert " + text + " is dismissed.", "PASS");
		} catch (NoAlertPresentException e) {
			reportStep("There is no alert present.", "FAIL");
			throw e;
		} catch (WebDriverException e) {
			reportStep("WebDriverException : " + e.getMessage(), "FAIL");
			throw e;
		}

	}

	public String getAlertText() {
		String text = "";
		try {
			Alert alert = driver.switchTo().alert();
			text = alert.getText();
		} catch (NoAlertPresentException e) {
			reportStep("There is no alert present.", "FAIL");
			throw e;
		} catch (WebDriverException e) {
			reportStep("WebDriverException : " + e.getMessage(), "FAIL");
			throw e;
		}
		return text;
	}

	public long takeSnap() {
		long number = (long) Math.floor(Math.random() * 900000000L) + 10000000L;
		try {
			FileUtils.copyFile(driver.getScreenshotAs(OutputType.FILE), new File("./images/" + number + ".png"));
		} catch (WebDriverException e) {
			System.out.println("The browser has been closed.");
			throw e;
		} catch (IOException e) {
			System.out.println("The snapshot could not be taken");
		}
		return number;
	}

	public void closeBrowser() {
		try {

			// reportStep("The browser is closed","PASS");
		} catch (Exception e) {
			// reportStep("The browser could not be closed","FAIL");
			throw e;
		} finally {

			driver.close();
		}
	}

	public void closeAllBrowsers() {
		try {
			driver.quit();
			reportStep("The opened browsers are closed", "PASS");
		} catch (Exception e) {
			reportStep("Unexpected error occured in Browser", "FAIL");
			throw e;
		}
	}

	public void waitForVisibility(WebElement ele, int waitTime) {

		try {
			WebDriverWait wait = new WebDriverWait(driver, waitTime);
			wait.until(ExpectedConditions.visibilityOf(ele));
		} catch (WebDriverException e) {
			throw e;
		}
	}

	public void killIEDriverInstance() throws IOException {

		try {

			Runtime.getRuntime().exec("taskkill /F /IM iedriver.exe");
		} catch (IOException e) {
			reportStep("Unexpected error occured in killing the driver instance", "FAIL");
			throw e;
		}
	}

		public WebElement FluentWaitCall(WebElement ele) {

		FluentWait waitTime = new FluentWait(ele);
		waitTime.withTimeout(30, TimeUnit.SECONDS);
		waitTime.pollingEvery(250, TimeUnit.MILLISECONDS);
		waitTime.ignoring(NoSuchElementException.class);
		return ele;

	}

	public void scrollView(WebElement ele) {

		try {

			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);

			reportStep("The element is viewed", "PASS");

		} catch (InvalidElementStateException e) {

			reportStep("The element: could not be viewed", "FAIL");

			throw e;

		} catch (WebDriverException e) {

			reportStep("Unknown exception occured while viewing in the field :", "FAIL");

			throw e;

		}

	}

	public void dblclick(WebElement ele) {
		String text = "";
		try {
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(ele));
			text = ele.getText();
			Actions act = new Actions(driver);
			act.doubleClick(ele).perform();
			reportStep("The element " + text + " is double clicked", "PASS");
		} catch (InvalidElementStateException e) {
			reportStep("The element: " + text + " could not be clicked", "FAIL");
			throw e;
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while clicking in the field :", "FAIL");
			throw e;
		}
	}

	public void mouseClick(WebElement ele)
	{
		try
		{
		action.moveToElement(ele).click().build().perform();
		reportStep("Clicked - "+ele, "PASS");
		}
		catch (InvalidElementStateException e) {
			reportStep("The element: " + ele + " could not be clicked", "FAIL");
			throw e;
		} catch (WebDriverException e) {
			reportStep("Unknown exception occured while clicking in the field :", "FAIL");
			throw e;
		}
	}
	
public void DateSelector(WebElement ele, String day) {
		
		try {
			//Actions action= new Actions(driver);
			waitForVisibility(ele,waitTime);
			 List<WebElement> columns = ele.findElements(By.tagName("td"));
			   System.out.println(columns.size());

			    //and if a cell matches with the current date then we will click it.
			    for (WebElement cell: columns) {
			        if (cell.getText().equals(day)) {
			        	System.out.println(day+" date found");
			        	cell.click();
			        	//action.moveToElement(cell).click().build().perform();
			        	System.out.println(day+" date clicked");
			        	reportStep( day+" day is selected from calender ","PASS");
			        	break;
			        }       
			    }
			
		} catch (WebDriverException e) {
			reportStep("The element: "+ele+" could not be found.", "FAIL");
			throw e;
		}	
		 
	}
	

public boolean comp_Dates(String date, String FromDate, String ToDate)  {
    try
    {
    	System.out.println("Inside compare dates function");
    	SimpleDateFormat fmt = new SimpleDateFormat("DD MMM YYYY");
        Date Fdate =fmt.parse(FromDate);
        Date Tdate =fmt.parse(ToDate);
        Date date1 = fmt.parse(date);     
        if (date1.compareTo(Fdate)>=0 & date1.compareTo(Tdate)<=0 ) {
        	return true;
        }else {
        	return false;
        }

    }
    catch (Exception ex ) {
         System.out.println(ex);  
         return false;
      }
    }



public int monthStringToInt(String month) {
	int intMonth = 0;
	switch(month)
	{
	case "January": intMonth = 1; break;
	case "February": intMonth = 2; break;
	case "March": intMonth = 3; break;
	case "April": intMonth = 4; break;
	case "May": intMonth = 5; break;
	case "June": intMonth = 6; break;
	case "July": intMonth = 7; break;
	case "August": intMonth = 8; break;
	case "September": intMonth = 9; break;
	case "October": intMonth = 10;  break;
	case "November": intMonth = 11; break;
	case "December": intMonth = 12; break;	
	}
	return intMonth;
}

public String monthIntToString(int month) {
	String strMonth = null;
	switch(month)
	{
	case 1: strMonth="January" ; break;
	case 2: strMonth="February"; break;
	case 3: strMonth="March"; break;
	case 4: strMonth="April"; break;
	case 5: strMonth="May"; break;
	case 6: strMonth="June"; break;
	case 7: strMonth="July"; break;
	case 8: strMonth="August"; break;
	case 9: strMonth="September"; break;
	case 10: strMonth="October";  break;
	case 11: strMonth="November"; break;
	case 12: strMonth="December"; break;	
	}
	return strMonth;
}

public void passingScenarioName(String value)
{
System.out.println(value);
}

}
	

