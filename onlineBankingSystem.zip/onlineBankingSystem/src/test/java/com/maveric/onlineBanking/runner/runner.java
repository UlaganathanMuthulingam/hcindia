package com.maveric.onlineBanking.runner;


import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.maveric.onlineBanking.common.SeMethods;

import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.TestNGCucumberRunner;


import cucumber.api.CucumberOptions;
import cucumber.api.Scenario;
import cucumber.api.java.Before;

@CucumberOptions(
		features = "src/test/java/com/maveric/onlineBanking/features/onlineBanking.feature"
		,glue={"com.maveric.onlineBanking.stepDef","hooks"}
		
		)

public class runner{
		private TestNGCucumberRunner testNGCucumberRunner;
		public static SeMethods semethod=new SeMethods();
		
		@BeforeSuite
		public void beforeSuite() {
			semethod.startResult();
			
		}

		@BeforeClass()
	    public void setUpClass() throws Exception {
	        testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
	        
	    }
	 
	    @Test( dataProvider = "features")
	    public void feature(CucumberFeatureWrapper cucumberFeature) {
	        testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());     
	    }
	    	 
	    @DataProvider
	    public Object[][] features() {
	        return testNGCucumberRunner.provideFeatures();
	    }
	 
	    @AfterClass()
	    public void tearDownClass() throws Exception {
	        testNGCucumberRunner.finish();
	    }
	    
		@AfterSuite
		public void endOfSuite()
		{
			semethod.endTestcase();
			semethod.endResult();	
		}
	    
	    }