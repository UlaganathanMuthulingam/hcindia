package hooks;

import com.maveric.onlineBanking.common.SeMethods;
import com.maveric.onlineBanking.runner.runner;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class CucumberHooks extends runner{
	
	@Before
	public void reportEachStepStarts(Scenario scenario)
	{
		String tagname=scenario.getSourceTagNames().toString();
		String latest=tagname.replaceAll("[@\\[\\]]", "");
		System.out.println(latest);
		semethod.startTestCase(latest, scenario.getName());

	}
	@After
	public void reportEachStepEnds()
	{
		
	}

}
